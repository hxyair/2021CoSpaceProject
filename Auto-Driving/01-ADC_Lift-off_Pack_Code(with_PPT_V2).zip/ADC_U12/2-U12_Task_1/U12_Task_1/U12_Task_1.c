////////////////////////////////////////
//
//	File : ai.c
//	CoSpace Robot
//	Version 1.0.0
//	Jan 1 2021
//	Copyright (C) 2021 CoSpace Robot. All Rights Reserved
//
//////////////////////////////////////
//
// ONLY C Code can be compiled.
//
/////////////////////////////////////

#define CsBot_AI_H//DO NOT delete this line
#ifndef CSBOT_REAL
#include <windows.h>
#include <stdio.h>
#include <math.h>
#define DLL_EXPORT extern __declspec(dllexport)
#define false 0
#define true 1
#endif
//The robot ID : six chars unique CID.
//Find it from your CoSpace Robot label or CoSpace program download GUI.
//Don't write the below line into two lines or more lines.
char AI_MyID[6] = {'1','2','3','4','5','6'};

int Duration = 0;
int CurAction = -1;
int CurGame = 0;
int MyState_1 = 0;
int US_Front = 0;
int IR_L3 = 0;
int IR_L2 = 0;
int IR_L1 = 0;
int IR_R1 = 0;
int IR_R2 = 0;
int IR_R3 = 0;
int CS_R = 0;
int CS_G = 0;
int CS_B = 0;
int RotationX = 0;
int RotationY = 0;
int RotationZ = 0;
int Time = 0;
int WheelLeft = 0;
int WheelRight = 0;
int LED_1 = 0;
int AI_SensorNum = 14;
int AI_TeamID = 1;   //Robot Team ID. 1:Blue Ream; 2:Red Team.

#define CsBot_AI_C//DO NOT delete this line

DLL_EXPORT void SetGameID(int GameID)
{
    CurGame = GameID;
}


DLL_EXPORT void SetMyState_1(int State_1)
{
    MyState_1 = State_1;
}

DLL_EXPORT int GetGameID()
{
    return CurGame;
}

#ifndef CSBOT_REAL

DLL_EXPORT char* GetDebugInfo()
{
    char info[3000];
    sprintf(info, "Duration=%d;CurAction=%d;CurGame=%d;MyState_1=%d;US_Front=%d;IR_L3=%d;IR_L2=%d;IR_L1=%d;IR_R1=%d;IR_R2=%d;IR_R3=%d;CS_R=%d;CS_G=%d;CS_B=%d;RotationX=%d;RotationY=%d;RotationZ=%d;Time=%d;WheelLeft=%d;WheelRight=%d;LED_1=%d;",Duration,CurAction,CurGame,MyState_1,US_Front,IR_L3,IR_L2,IR_L1,IR_R1,IR_R2,IR_R3,CS_R,CS_G,CS_B,RotationX,RotationY,RotationZ,Time,WheelLeft,WheelRight,LED_1);
    return info;
}
 
DLL_EXPORT char* GetTeamName()
{
     return "CoSpace";
}

DLL_EXPORT int GetCurAction()
{
    return CurAction;
}

#endif ////CSBOT_REAL

DLL_EXPORT void SetDataAI(volatile int* packet, volatile int *AI_IN)
{

    int sum = 0;

    MyState_1 = AI_IN[0]; packet[0] = MyState_1; sum += MyState_1;
    US_Front = AI_IN[1]; packet[1] = US_Front; sum += US_Front;
    IR_L3 = AI_IN[2]; packet[2] = IR_L3; sum += IR_L3;
    IR_L2 = AI_IN[3]; packet[3] = IR_L2; sum += IR_L2;
    IR_L1 = AI_IN[4]; packet[4] = IR_L1; sum += IR_L1;
    IR_R1 = AI_IN[5]; packet[5] = IR_R1; sum += IR_R1;
    IR_R2 = AI_IN[6]; packet[6] = IR_R2; sum += IR_R2;
    IR_R3 = AI_IN[7]; packet[7] = IR_R3; sum += IR_R3;
    CS_R = AI_IN[8]; packet[8] = CS_R; sum += CS_R;
    CS_G = AI_IN[9]; packet[9] = CS_G; sum += CS_G;
    CS_B = AI_IN[10]; packet[10] = CS_B; sum += CS_B;
    RotationX = AI_IN[11]; packet[11] = RotationX; sum += RotationX;
    RotationY = AI_IN[12]; packet[12] = RotationY; sum += RotationY;
    RotationZ = AI_IN[13]; packet[13] = RotationZ; sum += RotationZ;
    Time = AI_IN[14]; packet[14] = Time; sum += Time;
    packet[15] = sum;

}
DLL_EXPORT void GetCommand(int *AI_OUT)
{
    AI_OUT[0] = WheelLeft;
    AI_OUT[1] = WheelRight;
    AI_OUT[2] = LED_1;
}
void TurnTo(int curRot, int targetRot)
{
    int p0 = targetRot;
    int p3 = (targetRot + 3) % 360;
    int p15 = (targetRot + 15) % 360;
    int n3 = (targetRot - 3 + 360) % 360;
    int n15 = (targetRot - 15 + 360) % 360;
    int p180 = (targetRot + 180) % 360;
    int l = 0, r = 0;
    Duration = 6;
    //Within(-3,+3)deg, stop turing.
    l = n3; r = p3;
    if ((l < r && curRot > l && curRot < r) ||
    (l > r && (curRot > l || curRot < r)))
    {
        WheelLeft = 0;
        WheelRight = 0;
        Duration = 0;
        return;
    }
    //Within[3,15]deg,Turn Slowly
    l = p3; r = p15;
    if ((l < r && curRot >= l && curRot <= r) ||
        (l > r && (curRot >= l || curRot <= r)))
    {
        WheelLeft = 10;
        WheelRight = -10;
        return;
    }
    //Within[15,180]deg,Turn Faast
    l = p15; r = p180;
    if ((l < r && curRot >= l && curRot <= r) ||
       (l > r && (curRot >= l || curRot <= r)))
    {
        WheelLeft = 30;
        WheelRight = -30;
        return;
    }
    //Within[-15,-3]deg,Turn Slowly
    l = n15; r = n3;
    if ((l < r && curRot >= l && curRot <= r) ||
    (l > r && (curRot >= l || curRot <= r)))
    {
        WheelLeft = -10;
        WheelRight = 10;
        return;
    }
    //Within[-180,-15]deg,Turn Fast
    l = p180; r = n15;
    if ((l < r && curRot >= l && curRot <= r) ||
    (l > r && (curRot >= l || curRot <= r)))
    {
        WheelLeft = -30;
        WheelRight = 30;
        return;
    }
}
void Game0()
{

    if(Duration>0)
    {
        Duration--;
    }
    else if(US_Front<=12 && Time<=800)
    {
        Duration = 23;
        CurAction =1;
    }
    else if(US_Front<=12 && Time>=800 && Time<=2500)
    {
        Duration = 23;
        CurAction =2;
    }
    else if(US_Front<=12 && Time>=2500 && Time<=3800)
    {
        Duration = 23;
        CurAction =3;
    }
    else if(US_Front<=12 && Time>=3800)
    {
        Duration = 23;
        CurAction =4;
    }
    else if(IR_L1<=0)
    {
        Duration = 0;
        CurAction =5;
    }
    else if(IR_R1<=0)
    {
        Duration = 0;
        CurAction =6;
    }
    else if(IR_L2<=0)
    {
        Duration = 0;
        CurAction =7;
    }
    else if(IR_R2<=0)
    {
        Duration = 0;
        CurAction =8;
    }
    else if(IR_L3<=0)
    {
        Duration = 0;
        CurAction =9;
    }
    else if(IR_R3<=0)
    {
        Duration = 0;
        CurAction =10;
    }
    switch(CurAction)
    {
        case 1:
            WheelLeft=30;
            WheelRight=-10;
            LED_1=0;
            break;
        case 2:
            WheelLeft=-10;
            WheelRight=30;
            LED_1=0;
            break;
        case 3:
            WheelLeft=30;
            WheelRight=-10;
            LED_1=0;
            break;
        case 4:
            WheelLeft=-10;
            WheelRight=30;
            LED_1=0;
            break;
        case 5:
            WheelLeft=30;
            WheelRight=30;
            LED_1=0;
            break;
        case 6:
            WheelLeft=30;
            WheelRight=30;
            LED_1=0;
            break;
        case 7:
            WheelLeft=10;
            WheelRight=30;
            LED_1=0;
            break;
        case 8:
            WheelLeft=30;
            WheelRight=10;
            LED_1=0;
            break;
        case 9:
            WheelLeft=-20;
            WheelRight=30;
            LED_1=0;
            break;
        case 10:
            WheelLeft=30;
            WheelRight=-20;
            LED_1=0;
            break;
        default:
            break;
    }

}


DLL_EXPORT void OnTimer()
{
    switch (CurGame)
    {
        case 9:
            break;
        case 10:
            WheelLeft=0;
            WheelRight=0;
            LED_1=0;
            break;
        case 0:
            Game0();
            break;
        default:
            break;
    }
}

